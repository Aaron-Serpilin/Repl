package repls

/*
    The parent class of IntREPL and MultiSetREPL.
 */
abstract class REPLBase extends REPL {

    type Base
    //def evaluate (expression: String): Base = _
}
